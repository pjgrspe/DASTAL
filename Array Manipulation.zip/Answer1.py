x = [2, 5, 13, 17, 3, 89, 3, 5, 2, 90, 5, 65]

# accessing the elements 89 and 90
print('Element 1: ', x[5])
print("Element 2: ", x[9])

input('\nPress Enter to continue')