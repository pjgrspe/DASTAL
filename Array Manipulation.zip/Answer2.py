x = [2, 5, 13, 17, 3, 89, 3, 5, 2, 90, 5, 65]

# print elements of array from indices 1-8
print('Elements of array from indices 1-8 is: ')
for i in range (1,8):  
      print(x[i],end=" ")

input('\n\nPress Enter to continue')